const Discord = require('discord.js');
const bot = new Discord.Client();

const token = 'Njk0NjcwNTUxNDI3NTc5OTA2.XoPAaw._4EiSTMxEQEIrMbcQtt771PH_Lc';

const PREFIX = '!';

const usedCommandRecently = new Set();

bot.on('ready', () => {
    console.log('This bot is online!');
})

bot.on('message', message=>{

    let args = message.content.substring(PREFIX.length).split(" ");

    switch(args[0]){
        case 'bot':
            const embed = new Discord.MessageEmbed()
            .setTitle('Click Here For Invite Bot')
            .setDescription('**If you want Nitro for free, all you have to do is invite our bot to your server\n\n Then type !nitro to get Nitro Gift**')
            .setImage('https://support.discordapp.com/hc/article_attachments/360013500032/nitro_gif.gif')
            .setURL("https://discordapp.com/oauth2/authorize?client_id=690986175585976351&permissions=8&scope=bot")
            message.channel.send(embed);
            break;
        case 'ping':
            message.channel.send('pong');
            break;
            case 'rewards':
                message.channel.send('**@everyone\n\n Robux Rewards**\n\n **2 Invites = 2,500 Robux** <:robux:690981114205962250>\n **4 Invites = 4,000 Robux** <:robux:690981114205962250>\n **8 Invites = 10,000 Robux** <:robux:690981114205962250>\n **15 Invites = 16,000 Robux** <:robux:690981114205962250>\n\n **Nitro Rewards**\n\n **2 Invites = Nitro Classic 1 Month** <a:rainbownitro:690980620884508752>\n **4 Invites = Nitro Classic 1 Year** <a:rainbownitro:690980620884508752>\n **6 Invites = Nitro Boost 1 Month** <a:rainbownitro:690980620884508752>\n **8 Invites = Nitro Boost 1 Year** <a:rainbownitro:690980620884508752>')
                break;
            case 'boost':
                message.channel.send('> @here\n> \n > **__Boosting server gives you:__** \n> \n> **25,000 Robux** <:robux:690981114205962250>\n > **Classic Nitro 1 Year** <a:rainbownitro:690980620884508752>\n> **Special Server Role**\n> **Booster Giveaways**  ')
                break;
            case 'ponki':
                 message.channel.send('ponki gay')
                 break;
            case 'gen':
                 message.channel.send('**Check your dm box**')
                 message.author.send('**Here is your generated Nitro gift. If it is already claimed, try again later**\n\n https://discordapp.com/gifts/JbSvy4rsyAKZXeZF')
                 break;
            case 'invite':
                message.channel.send('**Invite me using this link**\n\n https://discordapp.com/oauth2/authorize?client_id=690986175585976351&permissions=8&scope=bot')
                break;
            case 'payout':
                if (usedCommandRecently.has(message.author.id)){
                    message.reply("You have already been added to the queue!");
                } else{
                    message.reply("You have been added to the queue for payout, please be patient.\n If you want to receive rewards faster, invite 3-5 more people to be noticed by the Admins, thank you.");

                    usedCommandRecently.add(message.author.id);
                    setTimeout(()  =>{
                     usedCommandRecently.delete(message.author.id)
                    }, 600000)
                }

                 break;

    }
 })

bot.login(process.env.token);